<?php

namespace App\Http\Controllers;

use App\Hidangan;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Pelanggan;
use App\Http\Controllers\PegawaiController;

class PegawaiHidanganController extends Controller {

    public function index(){
        if(!PegawaiController::getPegawai()){
            return redirect('pegawai/login');
        }
        $pegawai = PegawaiController::getPegawai();
        $hidangan = Hidangan::all();
        return view('pegawai.hidangan.index', compact('hidangan', 'pegawai'));
    }

    public function create(){
        if(!PegawaiController::getPegawai()){
            return redirect('pegawai/login');
        }
        $pegawai = PegawaiController::getPegawai();
        return view('pegawai.hidangan.create', 'pegawai');
    }

    public function store(Request $request){
        $this->validate($request, [
            'nama_hidangan' => 'required',
            'jenis_hidangan' => 'required'
        ]);

        $data = [
            'nama_hidangan' => $request->nama_hidangan,
            'jenis_hidangan' => $request->jenis_hidangan,
            'created_at' => date("Y-m-d H:i:s"),
            'updated_at' => date("Y-m-d H:i:s")
        ];
        Hidangan::insert($data);
        return redirect('pegawai/hidangan');
    }

    public function show($id)
    {
        //
    }

    public function edit($id){
        if(!PegawaiController::getPegawai()){
            return redirect('pegawai/login');
        }
        $pegawai = PegawaiController::getPegawai();
        $hidangan = Hidangan::where('id_hidangan', $id)->get();
        return view('pegawai.hidangan.edit', compact('hidangan', 'pegawai'));
    }

    public function update(Request $request, $id){
        $data = [
            'nama_hidangan' => $request->nama_hidangan,
            'jenis_hidangan' => $request->jenis_hidangan,
            'updated_at' => date("Y-m-d H:i:s"),
        ];

        Hidangan::where('id_hidangan', $id)->update($data);

        return redirect('pegawai/hidangan');
    }

    public function destroy($id){
        Hidangan::where('id_hidangan', '=', $id)->delete();
        return redirect('pegawai/hidangan');
    }
}

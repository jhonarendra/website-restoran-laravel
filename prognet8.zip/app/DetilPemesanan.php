<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DetilPemesanan extends Model
{
    protected $table = 'tb_detil_pemesanan';
}

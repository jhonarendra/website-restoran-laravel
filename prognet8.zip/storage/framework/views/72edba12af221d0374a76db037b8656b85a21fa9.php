<?php $__env->startSection('title', 'Pegawai'); ?>

<?php $__env->startSection('nama_pegawai', $pegawai['nama_pegawai']); ?>
<?php $__env->startSection('email_pegawai', $pegawai['email_pegawai']); ?>
<?php $__env->startSection('jabatan_pegawai', $pegawai['jabatan_pegawai']); ?>

<?php $__env->startSection('content'); ?>
                    <a href="<?php echo e(URL('pegawai/pegawai/create')); ?>" class="btn btn-success">Tambah Pegawai</a>

                    <table class="table table-bordered table-responsive mt-3">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nama</th>
                                <th>Email</th>
                                <th>Username</th>
                                <th>Jabatan</th>
                                <th>Tanggal Daftar</th>
                                <th>Tanggal Pembaruan</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $pegawais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pegawais): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($pegawais->id_pegawai); ?></td>
                                <td><?php echo e($pegawais->nama_pegawai); ?></td>
                                <td><?php echo e($pegawais->email_pegawai); ?></td>
                                <td><?php echo e($pegawais->username_pegawai); ?></td>
                                <td><?php echo e($pegawais->jabatan_pegawai); ?></td>
                                <td><?php echo e($pegawais->created_at); ?></td>
                                <td><?php echo e($pegawais->updated_at); ?></td>
                                <td>
                                    <a href="<?php echo e(URL('pegawai/pegawai/'.$pegawais->id_pegawai.'/edit')); ?>" class="btn btn-primary">Edit</a>
                                    <form action="<?php echo e(URL('pegawai/pegawai/'.$pegawais->id_pegawai)); ?>" method="POST">
                                        <?php echo e(csrf_field()); ?>

                                        <?php echo e(method_field('DELETE')); ?>

                                        <input type="submit" class="btn btn-danger" value="Hapus">
                                    </form>
                                    
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.pegawai', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
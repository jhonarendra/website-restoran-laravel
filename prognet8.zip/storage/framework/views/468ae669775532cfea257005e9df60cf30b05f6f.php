<?php $__env->startSection('title', 'Profil'); ?>

<?php $__env->startSection('nama_pegawai', $pegawai['nama_pegawai']); ?>
<?php $__env->startSection('email_pegawai', $pegawai['email_pegawai']); ?>
<?php $__env->startSection('jabatan_pegawai', $pegawai['jabatan_pegawai']); ?>

<?php $__env->startSection('content'); ?>
                    <a href="<?php echo e(URL('pegawai/pengaturan/'.$pegawai['id_pegawai'].'/edit')); ?>" class="btn-primary btn">Edit Profil</a>

                    <table class="table mt-3">
                        <tr>
                            <td>Nama</td>
                            <td><?php echo e($pegawai['nama_pegawai']); ?></td>
                        </tr>
                        <tr>
                            <td>Email</td>
                            <td><?php echo e($pegawai['email_pegawai']); ?></td>
                        </tr>
                        <tr>
                            <td>Username</td>
                            <td><?php echo e($pegawai['username_pegawai']); ?></td>
                        </tr>
                        <tr>
                            <td>Jabatan</td>
                            <td><?php echo e($pegawai['jabatan_pegawai']); ?></td>
                        </tr>
                    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.pegawai', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('title', 'Tambah Restoran'); ?>

<?php $__env->startSection('nama_pegawai', $pegawai['nama_pegawai']); ?>
<?php $__env->startSection('email_pegawai', $pegawai['email_pegawai']); ?>
<?php $__env->startSection('jabatan_pegawai', $pegawai['jabatan_pegawai']); ?>

<?php $__env->startSection('content'); ?>
                    <form method="POST" action="<?php echo e(URL('pegawai/restoran')); ?>">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group row">
                            <label for="" class="col-sm-2 col-form-label">Nama Restoran</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="" name="nama_restoran" placeholder="Nama Restoran" >
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="" class="col-sm-2 col-form-label">Alamat Restoran</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="" name="alamat_restoran" placeholder="Alamat Restoran" >
                            </div>
                        </div>
                        <div style="text-align: right;">
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.pegawai', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
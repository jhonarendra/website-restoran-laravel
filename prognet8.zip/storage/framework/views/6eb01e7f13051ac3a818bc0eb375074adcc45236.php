<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('nama_pegawai', $pegawai['nama_pegawai']); ?>
<?php $__env->startSection('email_pegawai', $pegawai['email_pegawai']); ?>
<?php $__env->startSection('jabatan_pegawai', $pegawai['jabatan_pegawai']); ?>

<?php $__env->startSection('content'); ?>
                    <form method="POST" action="<?php echo e(URL('pegawai/reservasi')); ?>">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group row">
                            <label for="" class="col-sm-2 col-form-label">Restoran</label>
                            <div class="col-sm-10">
                                <select name="id_restoran" class="form-control">
                                    <?php $__currentLoopData = $restoran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $restoran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($restoran->id_restoran); ?>"><?php echo e($restoran->nama_restoran.' - '.$restoran->alamat_restoran); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="" class="col-sm-2 col-form-label">Nama Pelanggan</label>
                            <div class="col-sm-10">
                                <select name="id_pelanggan" class="form-control">
                                    <?php $__currentLoopData = $pelanggan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pelanggan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($pelanggan->id_pelanggan); ?>"><?php echo e($pelanggan->nama_pelanggan); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="" class="col-sm-2 col-form-label">Nama Pegawai</label>
                            <div class="col-sm-10">
                                <select name="id_pegawai" class="form-control">
                                    <?php $__currentLoopData = $pegawais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pegawais): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($pegawais->id_pegawai); ?>"><?php echo e($pegawais->nama_pegawai); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="no_meja_reservasi" class="col-sm-2 col-form-label">Nomor Meja</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="no_meja_reservasi" name="no_meja_reservasi">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="status_reservasi" class="col-sm-2 col-form-label">Status</label>
                            <div class="col-sm-10">
                                <select name="status_reservasi" class="form-control">
                                    <option value="Batal">Batal</option>
                                    <option value="Dikonfirmasi">Dikonfirmasi</option>
                                    <option value="Menunggu Konfirmasi">Menunggu Konfirmasi</option>
                                    <option value="Sedang Berlangsung">Sedang Berlangsung</option>
                                    <option value="Selesai">Selesai</option>
                                </select>
                            </div>
                        </div>
                        <div style="text-align: right;">
                            <button type="submit" class="btn btn-primary">Buat Reservasi</button>
                        </div>
                    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.pegawai', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
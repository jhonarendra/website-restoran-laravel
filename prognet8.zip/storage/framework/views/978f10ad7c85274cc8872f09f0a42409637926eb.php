<?php $__env->startSection('title', 'Restoran'); ?>

<?php $__env->startSection('nama_pegawai', $pegawai['nama_pegawai']); ?>
<?php $__env->startSection('email_pegawai', $pegawai['email_pegawai']); ?>
<?php $__env->startSection('jabatan_pegawai', $pegawai['jabatan_pegawai']); ?>

<?php $__env->startSection('content'); ?>
                    <a href="<?php echo e(URL('pegawai/restoran/create')); ?>" class="btn btn-success">Tambah Restoran</a>

                    <table class="table table-bordered mt-3">
                        <thead>
                            <tr>
                                <th>Nama</th>
                                <th>Alamat</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $restoran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $restoran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($restoran->nama_restoran); ?></td>
                                <td><?php echo e($restoran->alamat_restoran); ?></td>
                                <td>
                                    <a href="<?php echo e(URL('pegawai/restoran/'.$restoran->id_restoran.'/edit')); ?>" class="btn btn-primary">Edit</a>
                                    <form action="<?php echo e(URL('pegawai/restoran/'.$restoran->id_restoran)); ?>" method="POST">
                                        <?php echo e(csrf_field()); ?>

                                        <?php echo e(method_field('DELETE')); ?>

                                        <input type="submit" class="btn btn-danger" value="Hapus">
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    Jangan hapus restoran, nanti semua pemesanan, detilpemesanan, reservasi yang id restorannya dihapus ikut kehapus
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.pegawai', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
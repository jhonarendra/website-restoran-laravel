<?php $__env->startSection('title', 'Reservasi'); ?>

<?php $__env->startSection('nama_pegawai', $pegawai['nama_pegawai']); ?>
<?php $__env->startSection('email_pegawai', $pegawai['email_pegawai']); ?>
<?php $__env->startSection('jabatan_pegawai', $pegawai['jabatan_pegawai']); ?>

<?php $__env->startSection('content'); ?>
<?php $__currentLoopData = $reservasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<form method="POST" action="<?php echo e(URL('pegawai/reservasi', $reservasi->id_reservasi)); ?>">
    <?php echo e(csrf_field()); ?>

    <?php echo e(method_field('PATCH')); ?>

    <div class="form-group row">
        <label for="" class="col-sm-2 col-form-label">Restoran</label>
        <div class="col-sm-10">
            <select name="id_restoran" class="form-control">
                <?php $__currentLoopData = $restoran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $restoran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($restoran->id_restoran); ?>"
                    <?php if($restoran->id_restoran == $reservasi->id_restoran): ?>
                    selected
                    <?php endif; ?>
                    ><?php echo e($restoran->nama_restoran.' - '.$restoran->alamat_restoran); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>
    <div class="form-group row">
        <label for="" class="col-sm-2 col-form-label">Nama Pelanggan</label>
        <div class="col-sm-10">
            <select name="id_pelanggan" class="form-control">
                <?php $__currentLoopData = $pelanggan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pelanggan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($pelanggan->id_pelanggan); ?>"
                    <?php if($pelanggan->id_pelanggan == $reservasi->id_pelanggan): ?>
                    selected
                    <?php endif; ?>
                    ><?php echo e($pelanggan->nama_pelanggan); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>
    <div class="form-group row">
        <label for="" class="col-sm-2 col-form-label">Nama Pegawai</label>
        <div class="col-sm-10">
            <select name="id_pegawai" class="form-control">
                <?php $__currentLoopData = $pegawais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pegawais): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($pegawais->id_pegawai); ?>"
                    <?php if($pegawais->id_pegawai == $reservasi->id_pegawai): ?>
                    selected
                    <?php endif; ?>
                    ><?php echo e($pegawais->nama_pegawai); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>
    <div class="form-group row">
        <label for="" class="col-sm-2 col-form-label">Nomor Meja</label>
        <div class="col-sm-10">
            <input type="text" name="no_meja_reservasi" class="form-control" id="" value="<?php echo e($reservasi->no_meja_reservasi); ?>">
        </div>
    </div>
    <div class="form-group row">
        <label for="" class="col-sm-2 col-form-label">Status</label>
        <div class="col-sm-10">
            <select name="status_reservasi" class="form-control">
                Batal, Dikonfirmasi, Menunggu Konfirmasi, Sedang Berlangsung, Selesai
                <option value="Batal"
                <?php if($reservasi->status_reservasi=='Batal'): ?>
                selected
                <?php endif; ?>
                >Batal</option>
                <option value="Dikonfirmasi"
                <?php if($reservasi->status_reservasi=='Dikonfirmasi'): ?>
                selected
                <?php endif; ?>
                >Dikonfirmasi</option>
                <option value="Menunggu Konfirmasi"
                <?php if($reservasi->status_reservasi=='Menunggu Konfirmasi'): ?>
                selected
                <?php endif; ?>
                >Menunggu Konfirmasi</option>
                <option value="Sedang Berlangsung"
                <?php if($reservasi->status_reservasi=='Sedang Berlangsung'): ?>
                selected
                <?php endif; ?>
                >Sedang Berlangsung</option>
                <option value="Selesai"
                <?php if($reservasi->status_reservasi=='Selesai'): ?>
                selected
                <?php endif; ?>
                >Selesai</option>
            </select>
        </div>
    </div>
    <input type="hidden" value="<?php echo e($reservasi->id_pelanggan); ?>" name="id_pelanggan" />
    <div style="text-align: right;">
        <button type="submit" class="btn btn-primary">Submit</button>
        <a class="btn btn-danger" href="<?php echo e(URL('pegawai/reservasi')); ?>">Batal</a>
    </div>
</form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.pegawai', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
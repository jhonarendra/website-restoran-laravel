<?php $__env->startSection('title', 'Hidangan'); ?>

<?php $__env->startSection('nama_pegawai', $pegawai['nama_pegawai']); ?>
<?php $__env->startSection('email_pegawai', $pegawai['email_pegawai']); ?>
<?php $__env->startSection('jabatan_pegawai', $pegawai['jabatan_pegawai']); ?>

<?php $__env->startSection('content'); ?>
                    <a href="<?php echo e(URL('pegawai/hidangan/create')); ?>" class="btn btn-success">Tambah Hidangan</a>

                    <table class="table table-bordered mt-3">
                        <thead>
                            <tr>
                                <th>Nama</th>
                                <th>Jenis</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $hidangan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hidangan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($hidangan->nama_hidangan); ?></td>
                                <td><?php echo e($hidangan->jenis_hidangan); ?></td>
                                <td>
                                    <a href="<?php echo e(URL('pegawai/hidangan/'.$hidangan->id_hidangan.'/edit')); ?>" class="btn btn-primary">Edit</a>
                                    <form action="<?php echo e(URL('pegawai/hidangan/'.$hidangan->id_hidangan)); ?>" method="POST">
                                        <?php echo e(csrf_field()); ?>

                                        <?php echo e(method_field('DELETE')); ?>

                                        <input type="submit" class="btn btn-danger" value="Hapus">
                                    </form>
                                    
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.pegawai', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
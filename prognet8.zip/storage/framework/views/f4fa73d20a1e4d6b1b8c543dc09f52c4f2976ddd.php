<?php $__env->startSection('title', 'Edit Pemesanan'); ?>

<?php $__env->startSection('nama_pegawai', $pegawai['nama_pegawai']); ?>
<?php $__env->startSection('email_pegawai', $pegawai['email_pegawai']); ?>
<?php $__env->startSection('jabatan_pegawai', $pegawai['jabatan_pegawai']); ?>

<?php $__env->startSection('content'); ?>
                    <?php $__currentLoopData = $pemesanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pemesanan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <form method="POST" action="<?php echo e(URL('pegawai/pemesanan', $pemesanan->id_pemesanan)); ?>">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('PATCH')); ?>

                        <div class="form-group row">
                            <label for="" class="col-sm-2 col-form-label">ID Restoran</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="" name="id_restoran" value="<?php echo e($pemesanan->id_restoran); ?>" >
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="" class="col-sm-2 col-form-label">ID Pelanggan</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="" name="id_pelanggan" value="<?php echo e($pemesanan->id_pelanggan); ?>" >
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="" class="col-sm-2 col-form-label">ID Pegawai</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="" name="id_pegawai" value="<?php echo e($pemesanan->id_pegawai); ?>" >
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="" class="col-sm-2 col-form-label">Total Pemesanan</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="" name="total_pemesanan" value="<?php echo e($pemesanan->total_pemesanan); ?>" >
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="" class="col-sm-2 col-form-label">Status</label>
                            <div class="col-sm-10">
                                <select name="status_pemesanan" class="form-control">
                                    <option value="Belum Dibayar"
                                    <?php if($pemesanan->status_pemesanan=='Belum Dibayar'): ?>
                                    selected
                                    <?php endif; ?>
                                    >Belum Dibayar</option>
                                    <option value="Lunas"
                                    <?php if($pemesanan->status_pemesanan=='Lunas'): ?>
                                    selected
                                    <?php endif; ?>
                                    >Lunas</option>
                                </select>
                            </div>
                        </div>
                        <div style="text-align: right;">
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </form>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.pegawai', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-3 mb-3">
            <div class="card mb-3" style="max-width: 20rem;">
                <div class="card-header">Profil</div>
                <div class="card-body">
                    <div style="text-align: center">
                        <img src="" style="width: 100px;height: 100px;border-radius: 50%;" />
                        <h4 class="card-title">
                            <!--Auth::user()->name--> Jhonarendra
                        </h4>
                        <p class="card-text">
                            <!--Auth::user()->email--> jhonarendra@gmail.com
                        </p>
                    </div>
                </div>
            </div>
            <ul class="list-group">
                <a href="<?php echo e(URL('pegawai')); ?>" class="list-group-item list-group-item-action">Dashboard</a>
                <a href="<?php echo e(URL('pegawai/reservasi')); ?>" class="list-group-item list-group-item-action">Reservasi</a>
                <a href="<?php echo e(URL('pegawai/pemesanan')); ?>" class="list-group-item list-group-item-action active">Pemesanan</a>
                <a href="<?php echo e(URL('pegawai/pelanggan')); ?>" class="list-group-item list-group-item-action">Pelanggan</a>
                <a href="<?php echo e(URL('pegawai/pegawai')); ?>" class="list-group-item list-group-item-action">Pegawai</a>
                <a href="<?php echo e(URL('pegawai/restoran')); ?>" class="list-group-item list-group-item-action">Restoran</a>
                <a href="<?php echo e(URL('pegawai/hidangan')); ?>" class="list-group-item list-group-item-action">Hidangan</a>
                <a href="<?php echo e(URL('pegawai/pengaturan')); ?>" class="list-group-item list-group-item-action">Pengaturan</a>
            </ul>
        </div>
        <div class="col-md-9">
            <div class="card">
                <div class="card-header">Edit Pemesanan</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <a href="<?php echo e(URL('pegawai/pemesanan/create')); ?>" class="btn btn-success">Tambah Pemesanan</a>

                    <table class="table table-bordered mt-3">
                        <thead>
                            <tr>
                                <th scope="col">Nama Hidangan</th>
                                <th scope="col">Jenis</th>
                                <th scope="col">Harga Satuan</th>
                                <th scope="col">Jumlah</th>
                                <th scope="col">Total Harga Hidangan</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $detil_pemesanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detil_pemesanan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($detil_pemesanan->nama_hidangan); ?></td>
                                <td><?php echo e($detil_pemesanan->jenis_hidangan); ?></td>
                                <td><?php echo e($detil_pemesanan->harga_hidangan); ?></td>
                                <td><?php echo e($detil_pemesanan->jumlah_hidangan); ?></td>
                                <td><?php echo e($detil_pemesanan->total_harga_hidangan); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
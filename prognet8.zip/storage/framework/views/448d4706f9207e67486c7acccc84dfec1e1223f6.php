<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-3 mb-3">
            <div class="card mb-3" style="max-width: 20rem;">
                <div class="card-header">Profil</div>
                <div class="card-body">
                    <div style="text-align: center">
                        <img src="" style="width: 100px;height: 100px;border-radius: 50%;" />
                        <h4 class="card-title">
                            <!--Auth::user()->name--> Jhonarendra
                        </h4>
                        <p class="card-text">
                            <!--Auth::user()->email--> jhonarendra@gmail.com
                        </p>
                    </div>
                </div>
            </div>
            <ul class="list-group">
                <a href="<?php echo e(URL('pelanggan')); ?>" class="list-group-item list-group-item-action">Dashboard</a>
                <a href="<?php echo e(URL('pelanggan/reservasi')); ?>" class="list-group-item list-group-item-action">Reservasi</a>
                <a href="<?php echo e(URL('pelanggan/pemesanan')); ?>" class="list-group-item list-group-item-action active">Pemesanan</a>
                <a href="<?php echo e(URL('pelanggan/pengaturan')); ?>" class="list-group-item list-group-item-action">Pengaturan</a>
            </ul>
        </div>
        <div class="col-md-9">
            <div class="card">
                <div class="card-header">Pemesanan</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <a href="<?php echo e(URL('pelanggan/pemesanan/create')); ?>" class="btn btn-success">Pesan</a>

                    <table class="table table-bordered mt-3">
                        <thead>
                            <tr>
                                <th scope="col">ID Pemesanan</th>
                                <th scope="col">Restoran</th>
                                <th scope="col">Tanggal Pemesanan</th>
                                <th scope="col">Nama Pegawai</th>
                                <th scope="col">Total Pemesanan</th>
                                <th scope="col">Status</th>
                                <th scope="col">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $pemesanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pemesanan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($pemesanan->id_pemesanan); ?></td>
                                <td><?php echo e($pemesanan->nama_restoran); ?></td>
                                <td><?php echo e($pemesanan->created_at); ?></td>
                                <td><?php echo e($pemesanan->nama_pegawai); ?></td>
                                <td><?php echo e($pemesanan->total_pemesanan); ?></td>
                                <td><?php echo e($pemesanan->status_pemesanan); ?></td>
                                <td>
                                    <a href="<?php echo e(URL('pelanggan/pemesanan/'.$pemesanan->id_pemesanan)); ?>" class="btn btn-primary">Rincian</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
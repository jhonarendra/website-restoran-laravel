<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-3 mb-3">
            <div class="card mb-3" style="max-width: 20rem;">
                <div class="card-header">Profil</div>
                <div class="card-body">
                    <div style="text-align: center">
                        <img src="" style="width: 100px;height: 100px;border-radius: 50%;" />
                        <h4 class="card-title">
                            <!--Auth::user()->name--> Jhonarendra
                        </h4>
                        <p class="card-text">
                            <!--Auth::user()->email--> jhonarendra@gmail.com
                        </p>
                    </div>
                </div>
            </div>
            <ul class="list-group">
                <a href="<?php echo e(URL('pegawai')); ?>" class="list-group-item list-group-item-action">Dashboard</a>
                <a href="<?php echo e(URL('pegawai/reservasi')); ?>" class="list-group-item list-group-item-action active">Reservasi</a>
                <a href="<?php echo e(URL('pegawai/pemesanan')); ?>" class="list-group-item list-group-item-action">Pemesanan</a>
                <a href="<?php echo e(URL('pegawai/pelanggan')); ?>" class="list-group-item list-group-item-action">Pelanggan</a>
                <a href="<?php echo e(URL('pegawai/pegawai')); ?>" class="list-group-item list-group-item-action">Pegawai</a>
                <a href="<?php echo e(URL('pegawai/restoran')); ?>" class="list-group-item list-group-item-action">Restoran</a>
                <a href="<?php echo e(URL('pegawai/hidangan')); ?>" class="list-group-item list-group-item-action">Hidangan</a>
                <a href="<?php echo e(URL('pegawai/pengaturan')); ?>" class="list-group-item list-group-item-action">Pengaturan</a>
            </ul>
        </div>
        <div class="col-md-9">
            <div class="card">
                <div class="card-header">Edit Reservasi</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <?php $__currentLoopData = $reservasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <form method="POST" action="<?php echo e(URL('pegawai/reservasi', $reservasi->id_reservasi)); ?>">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('PATCH')); ?>

                        <div class="form-group row">
                            <label for="" class="col-sm-2 col-form-label">ID Restoran</label>
                            <div class="col-sm-10">
                                <input type="text" name="id_restoran" class="form-control" id="" value="<?php echo e($reservasi->id_restoran); ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="" class="col-sm-2 col-form-label">ID Pelanggan</label>
                            <div class="col-sm-10">
                                <input type="text" name="id_pelanggan" class="form-control" id="" value="<?php echo e($reservasi->id_pelanggan); ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="" class="col-sm-2 col-form-label">ID Pegawai</label>
                            <div class="col-sm-10">
                                <input type="text" name="id_pegawai" class="form-control" id="" value="<?php echo e($reservasi->id_pegawai); ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="" class="col-sm-2 col-form-label">Nomor Meja</label>
                            <div class="col-sm-10">
                                <input type="text" name="no_meja_reservasi" class="form-control" id="" value="<?php echo e($reservasi->no_meja_reservasi); ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="" class="col-sm-2 col-form-label">Status</label>
                            <div class="col-sm-10">
                                <select name="status_reservasi" class="form-control">
                                    Batal, Dikonfirmasi, Menunggu Konfirmasi, Sedang Berlangsung, Selesai
                                    <option value="Batal"
                                    <?php if($reservasi->status_reservasi=='Batal'): ?>
                                    selected
                                    <?php endif; ?>
                                    >Batal</option>
                                    <option value="Dikonfirmasi"
                                    <?php if($reservasi->status_reservasi=='Dikonfirmasi'): ?>
                                    selected
                                    <?php endif; ?>
                                    >Dikonfirmasi</option>
                                    <option value="Menunggu Konfirmasi"
                                    <?php if($reservasi->status_reservasi=='Menunggu Konfirmasi'): ?>
                                    selected
                                    <?php endif; ?>
                                    >Menunggu Konfirmasi</option>
                                    <option value="Sedang Berlangsung"
                                    <?php if($reservasi->status_reservasi=='Sedang Berlangsung'): ?>
                                    selected
                                    <?php endif; ?>
                                    >Sedang Berlangsung</option>
                                    <option value="Selesai"
                                    <?php if($reservasi->status_reservasi=='Selesai'): ?>
                                    selected
                                    <?php endif; ?>
                                    >Selesai</option>
                                </select>
                            </div>
                        </div>
                        <input type="hidden" value="<?php echo e($reservasi->id_pelanggan); ?>" name="id_pelanggan" />
                        <div style="text-align: right;">
                            <button type="submit" class="btn btn-primary">Lanjutkan</button>
                            <a class="btn btn-danger" href="../reservasi">Batal</a>
                        </div>
                    </form>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
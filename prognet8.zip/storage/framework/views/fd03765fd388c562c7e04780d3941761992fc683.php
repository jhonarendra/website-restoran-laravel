<?php $__env->startSection('title', 'Pemesanan'); ?>

<?php $__env->startSection('nama_pegawai', $pegawai['nama_pegawai']); ?>
<?php $__env->startSection('email_pegawai', $pegawai['email_pegawai']); ?>
<?php $__env->startSection('jabatan_pegawai', $pegawai['jabatan_pegawai']); ?>

<?php $__env->startSection('content'); ?>
                    <a href="<?php echo e(URL('pegawai/pemesanan/create')); ?>" class="btn btn-success">Tambah Pemesanan</a>

                    <table class="table table-bordered table-responsive mt-3">
                        <thead>
                            <tr>
                                <th scope="col">ID Pemesanan</th>
                                <th scope="col">Nama Pelanggan</th>
                                <th scope="col">Restoran</th>
                                <th scope="col">Tanggal Pemesanan</th>
                                <th scope="col">Nama Pegawai</th>
                                <th scope="col">Total Pemesanan</th>
                                <th scope="col">Status</th>
                                <th scope="col">Tanggal Diperbarui</th>
                                <th scope="col">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $pemesanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pemesanan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($pemesanan->id_pemesanan); ?></td>
                                <td><?php echo e($pemesanan->nama_pelanggan); ?></td>
                                <td><?php echo e($pemesanan->nama_restoran); ?></td>
                                <td><?php echo e($pemesanan->created_at); ?></td>
                                <td><?php echo e($pemesanan->nama_pegawai); ?></td>
                                <td><?php echo e($pemesanan->total_pemesanan); ?></td>
                                <td><?php echo e($pemesanan->status_pemesanan); ?></td>
                                <td><?php echo e($pemesanan->updated_at); ?></td>
                                <td>
                                    <a href="<?php echo e(URL('pegawai/pemesanan/'.$pemesanan->id_pemesanan)); ?>" class="btn btn-primary">Rincian</a>
                                    <a href="<?php echo e(URL('pegawai/pemesanan/'.$pemesanan->id_pemesanan.'/edit')); ?>" class="btn btn-success">Edit</a>
                                    <form action="<?php echo e(URL('pegawai/pemesanan/'.$pemesanan->id_pemesanan)); ?>" method="POST">
                                        <?php echo e(csrf_field()); ?>

                                        <?php echo e(method_field('DELETE')); ?>

                                        <input type="submit" class="btn btn-danger" value="Hapus">
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.pegawai', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
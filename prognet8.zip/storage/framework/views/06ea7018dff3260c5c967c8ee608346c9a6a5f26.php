<!DOCTYPE html>
<html class="no-js" lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <meta name="description" content="Warung Ayu, Food Specialty" />
    <meta name="keywords" content="Food, Warung Ayu, AyuFood, Kuta, Bali" />
    <meta name="author" content="" />

    <!-- Facebook and Twitter integration -->
    <meta property="og:title" content=""/>
    <meta property="og:image" content=""/>
    <meta property="og:url" content=""/>
    <meta property="og:site_name" content=""/>
    <meta property="og:description" content=""/>
    <meta name="twitter:title" content="" />
    <meta name="twitter:image" content="" />
    <meta name="twitter:url" content="" />
    <meta name="twitter:card" content="" />


    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">

    <!-- Animate.css -->
    <link rel="stylesheet" href="<?php echo e(asset('css/animate.css')); ?>">
    <!-- Icomoon Icon Fonts-->
    <link rel="stylesheet" href="<?php echo e(asset('css/icomoon.css')); ?>">
    <!-- Simple Line Icons -->
    <link rel="stylesheet" href="<?php echo e(asset('css/simple-line-icons.css')); ?>">
    <!-- Datetimepicker -->
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap-datetimepicker.min.css')); ?>">
    <!-- Flexslider -->
    <link rel="stylesheet" href="<?php echo e(asset('css/flexslider.css')); ?>">
    <!-- Bootstrap  -->
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('css/styleback.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('font-awesome/css/font-awesome.css')); ?>">

    <style type="text/css">
        
    </style>


    <!-- Modernizr JS -->
    <script src="<?php echo e(asset('js/modernizr-2.6.2.min.js')); ?>"></script>
    <!-- FOR IE9 below -->
    <!--[if lt IE 9]>
    <script src="js/respond.min.js"></script>
    <![endif]-->
</head>
<body>

    <section id="container" >
        <!-- **********************************************************************************************************************************************************
        TOP BAR CONTENT & NOTIFICATIONS
        *********************************************************************************************************************************************************** -->
        <!--header start-->
        <header class="header black-bg">
            <div class="sidebar-toggle-box">
                <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
            </div>
            <!--logo start-->
            <a href="index.html" class="logo">MyRestoran</a>
            <!--logo end-->
            <div class="nav notify-row" id="top_menu">
            <!--  notification start -->
            
            <!--  notification end -->
            </div>
            <div class="top-menu">
            <ul class="nav pull-right top-menu">
            <li><a class="logout" href="<?php echo e(URL('pegawai/logout')); ?>">Logout</a></li>
            </ul>
            </div>
        </header>
        <!--header end-->

        <!--sidebar start-->
        <aside>
            <div id="sidebar" class="nav-collapse ">
                <!-- sidebar menu start-->
                <ul class="sidebar-menu" id="nav-accordion">
                    <p class="centered">
                        <a href="<?php echo e(URL('pegawai/pengaturan')); ?>">
                            <img src="josd.jpg" class="img-circle" width="60">
                        </a>
                    </p>
                    <h5 class="centered"><?php echo $__env->yieldContent('nama_pegawai'); ?></h5>
                    <p class="centered"><?php echo $__env->yieldContent('jabatan_pegawai'); ?></p>

                    <li class="mt">
                        <a <?php echo e((Request::is('pegawai') ? 'class=active' : '')); ?> href="<?php echo e(URL('pegawai')); ?>">
                            <i class="fa fa-dashboard"></i>
                            <span>Dashboard</span>
                        </a>
                    </li>
                    <li class="sub-menu">
                        <a <?php echo e((Request::is('pegawai/reservasi') ? 'class=active' : '')); ?> href="<?php echo e(URL('pegawai/reservasi')); ?>">
                            <i class="fa fa-pencil"></i>
                            <span>Reservasi</span>
                        </a>
                    </li>
                    <li class="sub-menu">
                        <a <?php echo e((Request::is('pegawai/pemesanan') ? 'class=active' : '')); ?> href="<?php echo e(URL('pegawai/pemesanan')); ?>">
                            <i class="fa fa-check-square"></i>
                            <span>Pemesanan</span>
                        </a>
                    </li>
                    <li class="sub-menu">
                        <a <?php echo e((Request::is('pegawai/pelanggan') ? 'class=active' : '')); ?> href="<?php echo e(URL('pegawai/pelanggan')); ?>">
                            <i class="fa fa-users"></i>
                            <span>Pelanggan</span>
                        </a>
                    </li>
                    <li class="sub-menu">
                        <a <?php echo e((Request::is('pegawai/pegawai') ? 'class=active' : '')); ?> href="<?php echo e(URL('pegawai/pegawai')); ?>">
                            <i class="fa fa-user"></i>
                            <span>Pegawai</span>
                        </a>
                    </li>
                    <li class="sub-menu">
                        <a <?php echo e((Request::is('pegawai/restoran') ? 'class=active' : '')); ?> href="<?php echo e(URL('pegawai/restoran')); ?>">
                            <i class="fa fa-home"></i>
                            <span>Restoran</span>
                        </a>
                    </li>
                    <li class="sub-menu">
                        <a <?php echo e((Request::is('pegawai/hidangan') ? 'class=active' : '')); ?> href="<?php echo e(URL('pegawai/hidangan')); ?>">
                            <i class="fa fa-list"></i>
                            <span>Hidangan</span>
                        </a>
                    </li>
                    <li class="sub-menu">
                        <a <?php echo e((Request::is('pegawai/pengaturan') ? 'class=active' : '')); ?> href="<?php echo e(URL('pegawai/pengaturan')); ?>">
                            <i class="fa fa-gear"></i>
                            <span>Pengaturan</span>
                        </a>
                    </li>
                </ul>
            <!-- sidebar menu end-->
            </div>
        </aside>
        <!--sidebar end-->

        <!--main content start-->
        <section id="main-content">
            <section class="wrapper">
                <?php echo $__env->yieldContent('content'); ?>
            </section>
        </section>

        
    </section>

	<!-- jQuery -->
	<script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
	<!-- jQuery Easing -->
	<script src="<?php echo e(asset('js/jquery.easing.1.3.js')); ?>"></script>
	<!-- Bootstrap -->
	<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
	<!-- Bootstrap DateTimePicker -->
	<script src="<?php echo e(asset('js/moment.js')); ?>"></script>
	<script src="<?php echo e(asset('js/bootstrap-datetimepicker.min.js')); ?>"></script>
	<!-- Waypoints -->
	<script src="<?php echo e(asset('js/jquery.waypoints.min.js')); ?>"></script>
	<!-- Stellar Parallax -->
	<script src="<?php echo e(asset('js/jquery.stellar.min.js')); ?>"></script>

	<!-- Flexslider -->
	<script src="<?php echo e(asset('js/jquery.flexslider-min.js')); ?>"></script>

    <script src="<?php echo e(asset('js/common-scripts.js')); ?>"></script>
	<script>
	    $(function () {
	       $('#date').datetimepicker();
	   });
	</script>
	<!-- Main JS -->
	<script src="<?php echo e(asset('js/main.js')); ?>"></script>
</body>
</html>
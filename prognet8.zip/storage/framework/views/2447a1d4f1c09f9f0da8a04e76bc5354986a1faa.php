<?php $__env->startSection('title', 'Reservasi'); ?>

<?php $__env->startSection('nama_pegawai', $pegawai['nama_pegawai']); ?>
<?php $__env->startSection('email_pegawai', $pegawai['email_pegawai']); ?>
<?php $__env->startSection('jabatan_pegawai', $pegawai['jabatan_pegawai']); ?>

<?php $__env->startSection('content'); ?>

<a href="<?php echo e(URL('pegawai/reservasi/create')); ?>" class="btn btn-success">Reservasi Baru</a>

<table class="table table-bordered table-responsive mt-3">
    <thead>
        <tr>
            <th scope="col">ID Reservasi</th>
            <th scope="col">Nama Pelanggan</th>
            <th scope="col">Restoran</th>
            <th scope="col">Tanggal Reservasi</th>
            <th scope="col">Nama Pegawai</th>
            <th scope="col">Nomor Meja</th>
            <th scope="col">Status</th>
            <th scope="col">Tanggal Pembaruan</th>
            <th scope="col">Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $reservasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($reservasi->id_reservasi); ?></td>
            <td><?php echo e($reservasi->nama_pelanggan); ?></td>
            <td><?php echo e($reservasi->nama_restoran); ?></td>
            <td><?php echo e($reservasi->created_at); ?></td>
            <td><?php echo e($reservasi->nama_pegawai); ?></td>
            <td><?php echo e($reservasi->no_meja_reservasi); ?></td>
            <td><?php echo e($reservasi->status_reservasi); ?></td>
            <td><?php echo e($reservasi->updated_at); ?></td>
            <td>
                <a href="<?php echo e(URL('pegawai/reservasi/'.$reservasi->id_reservasi.'/edit')); ?>" class="btn btn-primary">Edit</a>
                <form action="<?php echo e(URL('pegawai/reservasi/'.$reservasi->id_reservasi)); ?>" method="POST">
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('DELETE')); ?>

                    <input type="submit" class="btn btn-danger" value="Hapus">
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.pegawai', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
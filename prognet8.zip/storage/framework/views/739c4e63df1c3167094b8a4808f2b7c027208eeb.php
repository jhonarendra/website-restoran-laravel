<?php $__env->startSection('title', 'Profil'); ?>

<?php $__env->startSection('nama_pelanggan', $pelanggan['nama_pelanggan']); ?>
<?php $__env->startSection('email_pelanggan', $pelanggan['email_pelanggan']); ?>

<?php $__env->startSection('content'); ?>
                    <a href="<?php echo e(URL('pelanggan/pengaturan/'.$pelanggan['id_pelanggan'].'/edit')); ?>" class="btn-primary btn">Edit Profil</a>

                    <table class="table mt-3">
                        <tr>
                            <td>Nama</td>
                            <td><?php echo e($pelanggan['nama_pelanggan']); ?></td>
                        </tr>
                        <tr>
                            <td>Email</td>
                            <td><?php echo e($pelanggan['email_pelanggan']); ?></td>
                        </tr>
                        <tr>
                            <td>Username</td>
                            <td><?php echo e($pelanggan['username_pelanggan']); ?></td>
                        </tr>
                    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.pelanggan', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
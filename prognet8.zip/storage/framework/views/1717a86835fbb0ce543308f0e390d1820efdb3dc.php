<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('nama_pelanggan', $pelanggan['nama_pelanggan']); ?>
<?php $__env->startSection('email_pelanggan', $pelanggan['email_pelanggan']); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->yieldContent('nama_pelanggan'); ?><br />
<?php echo $__env->yieldContent('email_pelanggan'); ?><br />

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.pelanggan', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('nama_pegawai', $pegawai['nama_pegawai']); ?>
<?php $__env->startSection('email_pegawai', $pegawai['email_pegawai']); ?>
<?php $__env->startSection('jabatan_pegawai', $pegawai['jabatan_pegawai']); ?>

<?php $__env->startSection('content'); ?>
                    <?php $__currentLoopData = $restoran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $restoran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <form method="POST" action="<?php echo e(URL('pegawai/restoran', $restoran->id_restoran)); ?>">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('PATCH')); ?>

                        <div class="form-group row">
                            <label for="" class="col-sm-2 col-form-label">Nama Restoran</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="" name="nama_restoran" value="<?php echo e($restoran->nama_restoran); ?>" >
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="" class="col-sm-2 col-form-label">Alamat Restoran</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="" name="alamat_restoran" value="<?php echo e($restoran->alamat_restoran); ?>" >
                            </div>
                        </div>
                        <div style="text-align: right;">
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </form>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.pegawai', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
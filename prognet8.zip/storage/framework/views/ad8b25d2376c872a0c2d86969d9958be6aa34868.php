<?php $__env->startSection('title', 'Buat Pemesanan'); ?>

<?php $__env->startSection('nama_pelanggan', $pelanggan['nama_pelanggan']); ?>
<?php $__env->startSection('email_pelanggan', $pelanggan['email_pelanggan']); ?>

<?php $__env->startSection('content'); ?>
                    <form method="POST" action="<?php echo e(URL('pelanggan/pemesanan/')); ?>">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group row">
                            <label for="id_restoran" class="col-sm-2 col-form-label">Restoran</label>
                            <div class="col-sm-10">
                                <select name="id_restoran" class="form-control">
                                    <?php $__currentLoopData = $restoran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $restoran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($restoran->id_restoran); ?>"><?php echo e($restoran->nama_restoran.' - '.$restoran->alamat_restoran); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>

                        <div class="row">
                            <?php $__currentLoopData = $hidangan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hidangan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-3">
                                <input type="checkbox" name="hidangan[]" value="<?php echo e($hidangan->id_hidangan); ?>"><?php echo e($hidangan->nama_hidangan); ?>

                                <input type="text" class="form-control" name="harga_hidangan<?php echo e($hidangan->id_hidangan); ?>" value="<?php echo e($hidangan->harga_hidangan); ?>" readonly="">
                                <input type="text" class="form-control" name="jumlah_hidangan<?php echo e($hidangan->id_hidangan); ?>" placeholder="Jumlah">
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        <div style="text-align: right;">
                            <button type="submit" class="btn btn-primary">Submit</button>
                            <a class="btn btn-danger" href="<?php echo e(URL('pelanggan/pemesanan')); ?>">Batal</a>
                        </div>
                    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.pelanggan', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
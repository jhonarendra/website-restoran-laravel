<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-3 mb-3">
            <div class="card mb-3" style="max-width: 20rem;">
                <div class="card-header">Profil</div>
                <div class="card-body">
                    <div style="text-align: center">
                        <img src="" style="width: 100px;height: 100px;border-radius: 50%;" />
                        <h4 class="card-title">
                            <?php echo e($pegawai['nama_pegawai']); ?>

                        </h4>
                        <p class="card-text">
                            <?php echo e($pegawai['email_pegawai']); ?><br />
                            <?php echo e($pegawai['jabatan_pegawai']); ?>

                        </p>
                    </div>
                </div>
            </div>
            <ul class="list-group">
                <a href="<?php echo e(URL('pegawai')); ?>" class="list-group-item list-group-item-action">Dashboard</a>
                <a href="<?php echo e(URL('pegawai/reservasi')); ?>" class="list-group-item list-group-item-action">Reservasi</a>
                <a href="<?php echo e(URL('pegawai/pemesanan')); ?>" class="list-group-item list-group-item-action">Pemesanan</a>
                <a href="<?php echo e(URL('pegawai/pelanggan')); ?>" class="list-group-item list-group-item-action">Pelanggan</a>
                <a href="<?php echo e(URL('pegawai/pegawai')); ?>" class="list-group-item list-group-item-action active">Pegawai</a>
                <a href="<?php echo e(URL('pegawai/restoran')); ?>" class="list-group-item list-group-item-action">Restoran</a>
                <a href="<?php echo e(URL('pegawai/hidangan')); ?>" class="list-group-item list-group-item-action">Hidangan</a>
                <a href="<?php echo e(URL('pegawai/pengaturan')); ?>" class="list-group-item list-group-item-action">Pengaturan</a>
            </ul>
        </div>
        <div class="col-md-9">
            <div class="card">
                <div class="card-header">Edit Pegawai</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <?php $__currentLoopData = $pegawais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pegawais): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <form method="POST" action="<?php echo e(URL('pegawai/pegawai', $pegawais->id_pegawai)); ?>">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('PATCH')); ?>

                        <div class="form-group row">
                            <label for="" class="col-sm-2 col-form-label">Nama</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="" name="nama_pegawai" value="<?php echo e($pegawais->nama_pegawai); ?>" >
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="" class="col-sm-2 col-form-label">Email</label>
                            <div class="col-sm-10">
                                <input type="email" class="form-control" id="" name="email_pegawai" value="<?php echo e($pegawais->email_pegawai); ?>" >
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="" class="col-sm-2 col-form-label">Username</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="" name="username_pegawai" value="<?php echo e($pegawais->username_pegawai); ?>" >
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="" class="col-sm-2 col-form-label">Password</label>
                            <div class="col-sm-10">
                                <input type="password" class="form-control" id="" name="password_pegawai" placeholder="Password Pegawai" >
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="" class="col-sm-2 col-form-label">Jabatan Pegawai</label>
                            <div class="col-sm-10">
                                <select name="jabatan_pegawai" class="form-control">
                                    <option value="Admin"
                                    <?php if($pegawais->jabatan_pegawai=='Admin'): ?>
                                    selected
                                    <?php endif; ?>
                                    >Admin</option>
                                    <option value="Super Admin"
                                    <?php if($pegawais->jabatan_pegawai=='Super Admin'): ?>
                                    selected
                                    <?php endif; ?>
                                    >Super Admin</option>
                                </select>
                            </div>
                        </div>
                        <div style="text-align: right;">
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </form>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-3 mb-3">
            <div class="card mb-3" style="max-width: 20rem;">
                <div class="card-header">Profil</div>
                <div class="card-body">
                    <div style="text-align: center">
                        <img src="" style="width: 100px;height: 100px;border-radius: 50%;" />
                        <h4 class="card-title">
                            <?php echo e($pegawai['nama_pegawai']); ?>

                        </h4>
                        <p class="card-text">
                            <?php echo e($pegawai['email_pegawai']); ?><br />
                            <?php echo e($pegawai['jabatan_pegawai']); ?>

                        </p>
                    </div>
                </div>
            </div>
            <ul class="list-group">
                <a href="<?php echo e(URL('pegawai')); ?>" class="list-group-item list-group-item-action">Dashboard</a>
                <a href="<?php echo e(URL('pegawai/reservasi')); ?>" class="list-group-item list-group-item-action">Reservasi</a>
                <a href="<?php echo e(URL('pegawai/pemesanan')); ?>" class="list-group-item list-group-item-action active">Pemesanan</a>
                <a href="<?php echo e(URL('pegawai/pelanggan')); ?>" class="list-group-item list-group-item-action">Pelanggan</a>
                <a href="<?php echo e(URL('pegawai/pegawai')); ?>" class="list-group-item list-group-item-action">Pegawai</a>
                <a href="<?php echo e(URL('pegawai/restoran')); ?>" class="list-group-item list-group-item-action">Restoran</a>
                <a href="<?php echo e(URL('pegawai/hidangan')); ?>" class="list-group-item list-group-item-action">Hidangan</a>
                <a href="<?php echo e(URL('pegawai/pengaturan')); ?>" class="list-group-item list-group-item-action">Pengaturan</a>
            </ul>
        </div>
        <div class="col-md-9">
            <div class="card">
                <div class="card-header">Buat Pemesanan</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <form method="POST" action="<?php echo e(URL('pegawai/pemesanan/')); ?>">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group row">
                            <label for="id_restoran" class="col-sm-2 col-form-label">Restoran</label>
                            <div class="col-sm-10">
                                <select name="id_restoran" class="form-control">
                                    <?php $__currentLoopData = $restoran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $restoran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($restoran->id_restoran); ?>"><?php echo e($restoran->nama_restoran.' - '.$restoran->alamat_restoran); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="" class="col-sm-2 col-form-label">Nama Pegawai</label>
                            <div class="col-sm-10">
                                <select name="id_pegawai" class="form-control">
                                    <?php $__currentLoopData = $pegawais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pegawais): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($pegawais->id_pegawai); ?>"><?php echo e($pegawais->nama_pegawai); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="" class="col-sm-2 col-form-label">Nama Pelanggan</label>
                            <div class="col-sm-10">
                                <select name="id_pelanggan" class="form-control">
                                    <?php $__currentLoopData = $pelanggan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pelanggan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($pelanggan->id_pelanggan); ?>"><?php echo e($pelanggan->nama_pelanggan); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="row">
                            <?php $__currentLoopData = $hidangan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hidangan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-3">
                                <input type="checkbox" name="hidangan[]" value="<?php echo e($hidangan->id_hidangan); ?>"><?php echo e($hidangan->nama_hidangan); ?>

                                <input type="text" class="form-control" name="harga_hidangan<?php echo e($hidangan->id_hidangan); ?>" value="<?php echo e($hidangan->harga_hidangan); ?>" readonly="">
                                <input type="text" class="form-control" name="jumlah_hidangan<?php echo e($hidangan->id_hidangan); ?>" placeholder="Jumlah">
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <input type="hidden" name="id_pegawai" value="1">
                        <div style="text-align: right;">
                            <button type="submit" class="btn btn-primary">Kirim</button>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
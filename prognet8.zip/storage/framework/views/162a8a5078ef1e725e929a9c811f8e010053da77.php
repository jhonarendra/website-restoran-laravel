<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('nama_pegawai', $pegawai['nama_pegawai']); ?>
<?php $__env->startSection('email_pegawai', $pegawai['email_pegawai']); ?>
<?php $__env->startSection('jabatan_pegawai', $pegawai['jabatan_pegawai']); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->yieldContent('nama_pegawai'); ?><br />
<?php echo $__env->yieldContent('email_pegawai'); ?><br />
<?php echo $__env->yieldContent('jabatan_pegawai'); ?>
Contoh news Contoh news Contoh news Contoh newsContoh newsContoh newsContoh newsContoh newsContoh newsContoh newsContoh newsContoh newsContoh newsContoh newsContoh newsContoh newsContoh newsContoh newsContoh newsContoh newsContoh newsContoh newsContoh newsContoh newsContoh newsContoh newsContoh news 
<a href="" class="btn btn-lg btn-outline-secondary">Download Berkas</a>
<p class="text-muted mb-0">
	Pegawai Adminstrator
</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.pegawai', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>